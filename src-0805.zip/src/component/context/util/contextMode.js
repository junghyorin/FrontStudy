import { createContext } from "react";

const ctx = createContext(null);

export default ctx ; 


