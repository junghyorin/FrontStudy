

const GuestGreeting = () => {
    return (
        <h1>게스트 입장은 로그인 후 사용가능합니다.</h1>
    );
}

export default GuestGreeting ;