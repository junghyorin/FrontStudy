
const UserGreeting = () => {
    return (
        <h1>환영합니다....회원님</h1>
    );
}

export default UserGreeting ;
